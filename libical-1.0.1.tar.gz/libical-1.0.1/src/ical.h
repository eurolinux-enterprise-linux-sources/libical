/************************************************************************

 FILE:         ical.h
 CREATOR:      ajc 2008-sep-01

 (C) COPYRIGHT 2008 by Art Cancro
 http://libical.github.io/libical/

 This program is free software; you can redistribute it and/or modify
 it under the terms of either:

    The LGPL as published by the Free Software Foundation, version 2.1

  Or:

    The Mozilla Public License Version 1.0.

 ************************************************************************/

#ifdef _MSC_VER
#pragma message("WARNING: #include <ical.h> is deprecated.  Please #include <libical/ical.h> instead.")
#else
#warning "#include <ical.h> is deprecated.  Please #include <libical/ical.h> instead."
#endif
#include <libical/ical.h>
